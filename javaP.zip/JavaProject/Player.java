class Player extends Creature {
    public Player(String name, int hp, int ap, int agility) {
        super(name, hp, ap, agility);
    }
}