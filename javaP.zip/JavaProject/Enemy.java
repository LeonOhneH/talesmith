class Enemy extends Creature {
    public Enemy(String name, int hp, int ap, int agility) {
        super(name, hp, ap, agility);
    }
}